/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CategoryFrame extends JFrame implements ActionListener {

    JComboBox categoryBox;

    JButton startButton;

    public static String selectedCategory;

    public CategoryFrame() {

        setTitle("Select Category");

        setSize(400,300);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String categories[] = {
                "English",
                "Maths",
                "Computer"
        };

        categoryBox = new JComboBox(categories);

        categoryBox.setBounds(100,80,180,40);

        add(categoryBox);

        startButton = new JButton("Start Quiz");

        startButton.setBounds(100,150,180,40);

        add(startButton);

        startButton.addActionListener(this);
 //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        selectedCategory = categoryBox.getSelectedItem().toString();

        new QuizFrame();

        dispose();
    }
}
