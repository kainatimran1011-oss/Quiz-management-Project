/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author HP
 */
public abstract class Person {
    protected String username;
    protected String password;
    
    public Person(String username, String password){
        this.username= username;
        this.password= password;
    }
    
    public abstract void login();
}
