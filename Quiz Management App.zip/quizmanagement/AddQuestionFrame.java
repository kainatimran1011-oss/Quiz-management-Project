/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddQuestionFrame extends JFrame
        implements ActionListener {

    JLabel categoryLabel;
    JLabel questionLabel;
    JLabel option1Label;
    JLabel option2Label;
    JLabel option3Label;
    JLabel option4Label;
    JLabel correctLabel;

    JComboBox categoryBox;

    JTextField questionField;
    JTextField option1Field;
    JTextField option2Field;
    JTextField option3Field;
    JTextField option4Field;
    JTextField correctField;

    JButton addButton;
    JButton backButton;

    public AddQuestionFrame() {

        setTitle("Add Question");

        setSize(500, 700);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        categoryLabel =
                new JLabel("Category:");

        categoryLabel.setBounds(50,30,120,30);

        add(categoryLabel);

        String categories[] = {"English","Maths","Computer"};

        categoryBox =
                new JComboBox(categories);

        categoryBox.setBounds(180,30,220,30);

        add(categoryBox);

        questionLabel =
                new JLabel("Question:");

        questionLabel.setBounds(50,90,120,30);

        add(questionLabel);

        questionField =
                new JTextField();

        questionField.setBounds(180,90,220,30);

        add(questionField);

        option1Label =
                new JLabel("Option 1:");

        option1Label.setBounds(50,150,120,30);

        add(option1Label);

        option1Field =
                new JTextField();

        option1Field.setBounds(180,150,220,30);

        add(option1Field);

        option2Label =
                new JLabel("Option 2:");

        option2Label.setBounds(50,210,120,30);

        add(option2Label);

        option2Field =
                new JTextField();

        option2Field.setBounds(180, 210,220,30);

        add(option2Field);

        option3Label =
                new JLabel("Option 3:");

        option3Label.setBounds(50,270,120,30);

        add(option3Label);

        option3Field =
                new JTextField();

        option3Field.setBounds(180,270,220,30);

        add(option3Field);

        option4Label =
                new JLabel("Option 4:");

        option4Label.setBounds(50,330,120,30);

        add(option4Label);

        option4Field =
                new JTextField();

        option4Field.setBounds(180,330,220,30);

        add(option4Field);

        correctLabel =
                new JLabel("Correct Option:");

        correctLabel.setBounds(50,390,120,30);

        add(correctLabel);

        correctField = new JTextField();

        correctField.setBounds(180,390,220,30);

        add(correctField);
        
        addButton = new JButton("Add Question");

        addButton.setBounds(150,470,180,40);

        add(addButton);

        backButton = new JButton("Back");

        backButton.setBounds(150,530,180,40);

        add(backButton);

        addButton.addActionListener(this);

        backButton.addActionListener(this);
        
        //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == addButton) {

            try {

                String category = categoryBox.getSelectedItem().toString();

                String question = questionField.getText();

                String option1 = option1Field.getText();

                String option2 = option2Field.getText();

                String option3 = option3Field.getText();

                String option4 = option4Field.getText();

                int correctOption = Integer.parseInt(correctField.getText());

                Question q = new Question(category,question,option1,option2,option3,option4,correctOption);

                QuizManager.addQuestion(q);

                JOptionPane.showMessageDialog(this,"Question Added Successfully!");

                questionField.setText("");

                option1Field.setText("");

                option2Field.setText("");

                option3Field.setText("");

                option4Field.setText("");

                correctField.setText("");

            } catch(Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter correct data!"
                );
            }
        }

        if(e.getSource() == backButton) {

            new AdminDashboard();

            dispose();
        }
    }
}