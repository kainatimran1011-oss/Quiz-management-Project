/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame implements ActionListener {

    JLabel userLabel, passLabel, titleLabel;
    JTextField userField;
    JPasswordField passField;
    JButton loginButton;

    public LoginFrame() {

        // Frame settings
        setTitle("Quiz Management System");
        setSize(500, 350);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Background color
        getContentPane().setBackground(new Color(230, 240, 255));

        // Title label
        titleLabel = new JLabel("Quiz Management System");
        titleLabel.setBounds(80, 20, 350, 40);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 51, 153));
        add(titleLabel);

        // Username label
        userLabel = new JLabel("Username:");
        userLabel.setBounds(70, 90, 100, 30);
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userLabel.setForeground(Color.BLACK);
        add(userLabel);

        // Username field
        userField = new JTextField();
        userField.setBounds(180, 90, 220, 35);
        userField.setFont(new Font("Arial", Font.PLAIN, 14));
        add(userField);

        // Password label
        passLabel = new JLabel("Password:");
        passLabel.setBounds(70, 145, 100, 30);
        passLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passLabel.setForeground(Color.BLACK);
        add(passLabel);

        // Password field
        passField = new JPasswordField();
        passField.setBounds(180, 145, 220, 35);
        passField.setFont(new Font("Arial", Font.PLAIN, 14));
        add(passField);

        // Login button
        loginButton = new JButton("Login");
        loginButton.setBounds(180, 220, 140, 40);
        loginButton.setBackground(new Color(0, 102, 204));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setFocusPainted(false);
        add(loginButton);

        // Event handling
        loginButton.addActionListener(this);

        // Show frame
        setLocationRelativeTo(null); // Center on screen
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String username = userField.getText();
        String password = new String(passField.getPassword());

        // Admin login
        if (username.equals("admin") && password.equals("123")) {
            new AdminDashboard();
        } else {
            // Normal user login
            new UserDashboard();
        }

        dispose();
    }
}