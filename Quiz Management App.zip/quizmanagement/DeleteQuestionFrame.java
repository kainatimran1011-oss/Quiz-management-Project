/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DeleteQuestionFrame extends JFrame
        implements ActionListener {

    JLabel indexLabel;

    JTextField indexField;

    JButton deleteButton;
    JButton backButton;

    public DeleteQuestionFrame() {

       
        setTitle("Delete Question");

        setSize(400,300);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        indexLabel = new JLabel("Question Index:");

        indexLabel.setBounds(50,50,120,30);

        add(indexLabel);

        indexField = new JTextField();

        indexField.setBounds(180,50,120,30);

        add(indexField);

        deleteButton = new JButton("Delete");

        deleteButton.setBounds(120,120,120,40);

        add(deleteButton);

        backButton = new JButton("Back");

        backButton.setBounds(120,180,120,40);

        add(backButton);

        deleteButton.addActionListener(this);

        backButton.addActionListener(this);
 //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == deleteButton) {

            try {

                int index =
                        Integer.parseInt(
                                indexField.getText()
                        );

                QuizManager.deleteQuestion(index);

                JOptionPane.showMessageDialog(this,
                        "Question Deleted!");

                indexField.setText("");

            } catch(Exception ex) {

                JOptionPane.showMessageDialog(this,
                        "Invalid Index!");
            }
        }

        if(e.getSource() == backButton) {

            new AdminDashboard();

            dispose();
        }
    }
}
