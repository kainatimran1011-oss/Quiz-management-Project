/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author HP
 */
public class admin extends Person {
    public admin(String username,String password){
        super(username, password);
    }
    
    @Override
    public void login()
    {
        System.out.println("Admin Logged in");
    }
}
