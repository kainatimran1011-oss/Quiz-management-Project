/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard extends JFrame {

    JButton addQuestionButton;
    JButton updateQuestionButton;
    JButton deleteQuestionButton;
    JButton logoutButton;

    public AdminDashboard() {

        setTitle("Admin Dashboard");

        setSize(500, 450);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                addQuestionButton =
                new JButton("Add Question");

        addQuestionButton.setBounds(
                140,
                50,
                200,
                40
        );

        add(addQuestionButton);

        updateQuestionButton =
                new JButton("Update Question");

        updateQuestionButton.setBounds(
                140,
                120,
                200,
                40
        );

        add(updateQuestionButton);

        deleteQuestionButton =
                new JButton("Delete Question");

        deleteQuestionButton.setBounds(
                140,
                190,
                200,
                40
        );

        add(deleteQuestionButton);

        logoutButton =
                new JButton("Logout");

        logoutButton.setBounds(
                140,
                260,
                200,
                40
        );

        add(logoutButton);

        addQuestionButton.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(
                    ActionEvent e) {

                new AddQuestionFrame();
            }
        });
 //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));
        updateQuestionButton.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(
                    ActionEvent e) {

                new UpdateQuestionFrame();
            }
        });

                deleteQuestionButton.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(
                    ActionEvent e) {

                new DeleteQuestionFrame();
            }
        });

        logoutButton.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(
                    ActionEvent e) {

                new LoginFrame();

                dispose();
            }
        });

        setVisible(true);
    }
}
