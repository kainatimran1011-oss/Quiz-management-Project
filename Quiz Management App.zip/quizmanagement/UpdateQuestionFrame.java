/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UpdateQuestionFrame extends JFrame
        implements ActionListener {

    JLabel indexLabel;
    JLabel categoryLabel;
    JLabel questionLabel;
    JLabel option1Label;
    JLabel option2Label;
    JLabel option3Label;
    JLabel option4Label;
    JLabel correctLabel;

     JTextField indexField;
    JTextField questionField;
    JTextField option1Field;
    JTextField option2Field;
    JTextField option3Field;
    JTextField option4Field;
    JTextField correctField;

    JComboBox categoryBox;

    JButton loadButton;
    JButton updateButton;
    JButton backButton;

    public UpdateQuestionFrame() {

        setTitle("Update Question");

        setSize(550, 700);

        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        indexLabel =
                new JLabel("Question Index:");

        indexLabel.setBounds(50,20,120,30);

        add(indexLabel);

        indexField = new JTextField();

        indexField.setBounds(200,20,220,30);

        add(indexField);

        categoryLabel =
                new JLabel("Category:");

        categoryLabel.setBounds(50,70,120,30);

        add(categoryLabel);

        String categories[] = {
                "English",
                "Maths",
                "Computer"
        };

        categoryBox =
                new JComboBox(categories);

        categoryBox.setBounds(200,70,220,30);

        add(categoryBox);

        questionLabel =
                new JLabel("Question:");

        questionLabel.setBounds(50,120,120,30);

        add(questionLabel);

        questionField =
                new JTextField();

        questionField.setBounds(200,120,220,30);

        add(questionField);

        option1Label =
                new JLabel("Option 1:");

        option1Label.setBounds(50,170,120,30);

        add(option1Label);

        option1Field =
                new JTextField();

        option1Field.setBounds(200,170,220,30);

        add(option1Field);

        option2Label =
                new JLabel("Option 2:");

        option2Label.setBounds(50,220,120,30);

        add(option2Label);

        option2Field =
                new JTextField();

        option2Field.setBounds(200,220,220,30);

        add(option2Field);

        option3Label =
                new JLabel("Option 3:");

        option3Label.setBounds(50,270,120,30);

        add(option3Label);

        option3Field =
                new JTextField();

        option3Field.setBounds(200,270,220,30);

        add(option3Field);

        option4Label =
                new JLabel("Option 4:");

        option4Label.setBounds(50,320,120,30);

        add(option4Label);

        option4Field =
                new JTextField();

        option4Field.setBounds(200,320,220,30);

        add(option4Field);

        correctLabel =
                new JLabel("Correct Option:");

        correctLabel.setBounds(50,370,120,30);

        add(correctLabel);

        correctField =
                new JTextField();

        correctField.setBounds(200,370,220,30);

        add(correctField);

        loadButton =
                new JButton("Load Question");

        loadButton.setBounds(170,440,180,40);

        add(loadButton);

        updateButton =
                new JButton("Update");

        updateButton.setBounds(170,500,180,40);

        add(updateButton);

        backButton =
                new JButton("Back");

        backButton.setBounds(170,560,180,40);

        add(backButton);

        loadButton.addActionListener(this);

        updateButton.addActionListener(this);

        backButton.addActionListener(this);
        //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == loadButton) {

            try {

                int index =
                        Integer.parseInt(
                                indexField.getText()
                        );

                Question q =
                        QuizManager.getQuestion(index);

                if(q != null) {

                    categoryBox.setSelectedItem(q.getCategory());

                    questionField.setText(q.getQuestion());

                    option1Field.setText(q.getOption1());

                    option2Field.setText(q.getOption2());

                    option3Field.setText(q.getOption3());

                    option4Field.setText(q.getOption4());

                    correctField.setText(
                            String.valueOf(q.getCorrectOption())
                    );

                } else {

                    JOptionPane.showMessageDialog(this,"Question Not Found!");
                }

            } catch(Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Invalid Index!"
                );
            }
        }

        if(e.getSource() == updateButton) {

            try {

                int index =
                        Integer.parseInt(indexField.getText());

                String category =categoryBox.getSelectedItem().toString();

                String question = questionField.getText();

                String option1 = option1Field.getText();

                String option2 = option2Field.getText();

                String option3 = option3Field.getText();

                String option4 = option4Field.getText();

                int correctOption = Integer.parseInt( correctField.getText());

                Question updatedQuestion =
                        new Question(category,question,option1,option2,option3,option4, correctOption );

                        QuizManager.updateQuestion(index,updatedQuestion);

                JOptionPane.showMessageDialog( this, "Question Updated Successfully!" );

            } catch(Exception ex) { JOptionPane.showMessageDialog( this,"Invalid Data!" );
            }
        }

        if(e.getSource() == backButton) {

            new AdminDashboard();

            dispose();
        }
    }
}