/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author HP
 */
import java.util.ArrayList;

public class QuizManager {

    public static ArrayList<Question> questions =
            new ArrayList<>();

    
    public static void addQuestion(Question q)  //Create
    {

        questions.add(q);
    }

    
    public static ArrayList<Question> getQuestions() //Read
    {

        return questions;
    }

    
    public static void deleteQuestion(int index) //delete
    {

        if(index >= 0 && index < questions.size()) {

            questions.remove(index);
        }
    }

    
    public static void updateQuestion(int index,Question newQuestion) //update
    {

        if(index >= 0 && index < questions.size()) {

            questions.set(index, newQuestion);
        }
    }
    
    public static Question getQuestion(int index) {

    if(index >= 0 && index < questions.size()) {

        return questions.get(index);
    }

    return null;
    }
}
