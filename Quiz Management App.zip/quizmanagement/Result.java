/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author HP
 */
public class Result {

    private int score;

    public Result(int score) {
        this.score = score;
    }

    public int getScore() {
        return score;
    }
}
