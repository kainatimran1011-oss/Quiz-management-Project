/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizmanagement;
/**
 *
 * @author HP
 */
public class QuizManagement {

    public static void main(String[] args) {
        
       QuizManager.addQuestion(
    new Question(
        "English",
        "Which is a noun?",
        "Run",
        "Beautiful",
        "School",
        "Quickly",
        3
    )
);

QuizManager.addQuestion(
        new Question(
        "English",
        "Choose the correct spelling.",
        "Recieve",
        "Receive",
        "Receeve",
        "Receve",
        2
    )
);

QuizManager.addQuestion(
    new Question(
        "English",
        "What is the opposite of 'Hot'?",
        "Cold",
        "Warm",
        "Boil",
        "Heat",
        1
    )
);

QuizManager.addQuestion(
    new Question(
        "English",
        "Which sentence is correct?",
        "He go to school.",
        "He goes to school.",
        "He going to school.",
        "He gone to school.",
        2
    )
);

QuizManager.addQuestion(
    new Question(
        "English",
        "Which is a pronoun?",
        "Ali",
        "Table",
        "She",
        "Book",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Maths",
        "What is 5 + 3?",
        "6",
        "7",
        "8",
        "9",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Maths",
        "What is 10 - 4?",
        "5",
        "6",
        "7",
        "8",
        2
    )
);

QuizManager.addQuestion(
    new Question(
        "Maths",
        "What is 6 x 2?",
        "10",
        "11",
        "12",
        "14",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Maths",
        "What is 20 / 5?",
        "2",
        "3",
        "4",
        "5",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Maths",
        "What is the square of 4?",
        "8",
        "12",
        "14",
        "16",
        4
    )
);

QuizManager.addQuestion(
    new Question(
        "Computer",
        "What does CPU stand for?",
        "Central Process Unit",
        "Central Processing Unit",
        "Computer Personal Unit",
        "Central Program Unit",
        2
    )
);

QuizManager.addQuestion(
    new Question(
        "Computer",
        "Which device is used for input?",
        "Monitor",
        "Printer",
        "Keyboard",
        "Speaker",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Computer",
        "Which language is used in this project?",
        "Python",
        "C++",
        "Java",
        "PHP",
        3
    )
);

QuizManager.addQuestion(
    new Question(
        "Computer",
        "Which component stores data permanently?",
        "RAM",
        "ROM",
        "CPU",
        "Cache",
        2
    )
);

QuizManager.addQuestion(
    new Question(
        "Computer",
        "Which of these is an operating system?",
        "Windows",
        "Keyboard",
        "Mouse",
        "Printer",
        1
    )
);
 
        new LoginFrame();
    }
}