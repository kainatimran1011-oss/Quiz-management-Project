/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class QuizFrame extends JFrame implements ActionListener {

    JLabel questionLabel;
    JLabel timerLabel;

    JRadioButton option1;
    JRadioButton option2;
    JRadioButton option3;
    JRadioButton option4;

    ButtonGroup group;
    JButton nextButton;

    ArrayList<Question> questions;

    int currentQuestion = 0;
    int score = 0;

    Timer timer;
    int timeLeft = 30;

    public QuizFrame() {

        // Sirf selected category ke questions load karo
        questions = new ArrayList<>();

        String selected = CategoryFrame.selectedCategory;

        for (Question q : QuizManager.getQuestions()) {
            if (q.getCategory().equalsIgnoreCase(selected)) {
                questions.add(q);
            }
        }

        // Agar selected category ka koi question nahi hai
        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No questions available for " + selected);
            dispose();
            return;
        }
        getContentPane().setBackground(new Color(230, 236, 245));

        setTitle("Quiz");
        setSize(600, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        questionLabel = new JLabel();
        questionLabel.setBounds(50, 30, 500, 30);
        add(questionLabel);

        // Timer label
        timerLabel = new JLabel("Time Left: 30");
        timerLabel.setBounds(450, 10, 120, 30);
        add(timerLabel);

        // Radio buttons
        option1 = new JRadioButton();
        option1.setBounds(50, 80, 300, 30);

        option2 = new JRadioButton();
        option2.setBounds(50, 120, 300, 30);

        option3 = new JRadioButton();
        option3.setBounds(50, 160, 300, 30);

        option4 = new JRadioButton();
        option4.setBounds(50, 200, 300, 30);

        // Group for single selection
        group = new ButtonGroup();
        group.add(option1);
        group.add(option2);
        group.add(option3);
        group.add(option4);

        add(option1);
        add(option2);
        add(option3);
        add(option4);

        // Next button
        nextButton = new JButton("Next");
        nextButton.setBounds(220, 280, 100, 40);
        add(nextButton);
        nextButton.addActionListener(this);

        loadQuestion();
        startTimer();
        setVisible(true);
    }

    public void loadQuestion() {

        if (currentQuestion >= questions.size()) {
            timer.stop();
            JOptionPane.showMessageDialog(this,
                    "Quiz Finished!\nYour Score: " + score);
            dispose();
            return;
        }

        Question q = questions.get(currentQuestion);

        questionLabel.setText(q.getQuestion());

        option1.setText(q.getOption1());
        option2.setText(q.getOption2());
        option3.setText(q.getOption3());
        option4.setText(q.getOption4());

        group.clearSelection();

        timeLeft = 30;
        timerLabel.setText("Time Left: 30");
    }

    public void startTimer() {

        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                timeLeft--;
                timerLabel.setText("Time Left: " + timeLeft);

                if (timeLeft == 0) {
                    checkAnswer();
                    currentQuestion++;
                    loadQuestion();
                }
            }
        });

        timer.start();
    }

    public void checkAnswer() {

        int selectedAnswer = 0;

        if (option1.isSelected()) {
            selectedAnswer = 1;
        } else if (option2.isSelected()) {
            selectedAnswer = 2;
        } else if (option3.isSelected()) {
            selectedAnswer = 3;
        } else if (option4.isSelected()) {
            selectedAnswer = 4;
        }

        int correctAnswer =
                questions.get(currentQuestion).getCorrectOption();

        if (selectedAnswer == correctAnswer) {
            score++;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        checkAnswer();
        currentQuestion++;
        loadQuestion();
    }
}