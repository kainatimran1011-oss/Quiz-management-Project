/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserDashboard extends JFrame implements ActionListener {

    JButton startQuizBtn;
    JLabel titleLabel;

    public UserDashboard() {

        setTitle("User Dashboard");
        setSize(400, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Background Color
        getContentPane().setBackground(new Color(230, 236, 245));

        // Title
        titleLabel = new JLabel("User Dashboard");
        titleLabel.setBounds(70, 40, 300, 40);
        titleLabel.setFont(new Font("Century Gothic", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 51, 153));
        add(titleLabel);

        // Button
        startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));

        // Remove Focus Border
        startQuizBtn.setFocusPainted(false);

        // Button Border
        startQuizBtn.setBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2));

        add(startQuizBtn);

        startQuizBtn.addActionListener(this);

        setLocationRelativeTo(null);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        new CategoryFrame();
        dispose();
    }
}