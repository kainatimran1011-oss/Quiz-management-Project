/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author HP
 */
public class User extends Person {
    public User(String username, String password){
        super(username, password);
    }
    @Override
    public void login(){
        System.out.println("User Logged in");
    }
}

