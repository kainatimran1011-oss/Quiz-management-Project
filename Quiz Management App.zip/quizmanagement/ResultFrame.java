/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizmanagement;

import java.awt.*;
/**
 *
 * @author HP
 */
import javax.swing.*;

public class ResultFrame extends JFrame {

    JLabel totalQuestionsLabel;
    JLabel correctAnswersLabel;
    JLabel finalScoreLabel;

    public ResultFrame(int totalQuestions, int correctAnswers) {

        
        int finalScore = correctAnswers;

        setTitle("Quiz Result");
        setSize(400, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JLabel heading = new JLabel("Quiz Result");
        heading.setBounds(150, 20, 150, 30);
        add(heading);
      
        //background
        getContentPane().setBackground(new Color(230, 236, 245));
        // Button
        JButton startQuizBtn = new JButton("Start Quiz");
        startQuizBtn.setBounds(110, 120, 150, 45);

        // Button Colors
        startQuizBtn.setBackground(new Color(0, 102, 204));
        startQuizBtn.setForeground(Color.WHITE);

        // Button Font
        startQuizBtn.setFont(new Font("Century Gothic", Font.BOLD, 16));

                totalQuestionsLabel =
                new JLabel("Total Questions: " + totalQuestions);

        totalQuestionsLabel.setBounds(100, 80, 200, 30);
        add(totalQuestionsLabel);

               correctAnswersLabel =
                new JLabel("Correct Answers: " + correctAnswers);

        correctAnswersLabel.setBounds(100, 120, 200, 30);
        add(correctAnswersLabel);

               finalScoreLabel =
                new JLabel("Final Score: " + finalScore);

        finalScoreLabel.setBounds(100, 160, 200, 30);
        add(finalScoreLabel);

        setVisible(true);
    }
}